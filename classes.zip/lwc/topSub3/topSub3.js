import { LightningElement } from 'lwc';
import TRAILHEAD_LOGO from '@salesforce/resourceUrl/himawari';

export default class TopSub3 extends LightningElement {

    trailheadLogoUrl = TRAILHEAD_LOGO;
}