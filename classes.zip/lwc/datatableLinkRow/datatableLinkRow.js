/*
 * 機能名：（共通）カスタムDataTableの子コンポーネント
 * 作成日：2023-10-14	
 * 作成者：HITACHI　カク
 * 更新日：2023-10-14
 * 更新者：HITACHI　カク
*/
import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'
// APEX　検索処理メソッド  
import searchObjectRecords from '@salesforce/apex/C_LWC_TorihikisakiSearch_CTRL.searchObjectRecords';

// 処理状態
const RESULT_STATUS_OK = 'OK';

export default class DatatableLinkRow extends NavigationMixin(LightningElement) {
    // オブジェクトAPI名
    @api objectName;
    // オブジェクトID
    @api objectId;
    // リンク名
    @api linkName;
    // エラーメッセージ
    errorMessages;

    /**
     * 機能名：リンククリック時の処理
     * 機能概要：リンククリック時に、APEXの検索処理を呼び出し、検索結果に応じて画面遷移を行う
     */
    handleClick(){
        searchObjectRecords({objectName: this.objectName, objectId: this.objectId})
        .then(result => {
            if(result.status == RESULT_STATUS_OK) {
                this.navigateToRecordViewPage();
            } else {
                this.errorMessages = result.message;
                this.showErrorToast();
            }
        });
    }

    /**
     * 機能名：エラートースト表示
     * 機能概要：エラートーストを表示する
     */
    showErrorToast() {
        const evt = new ShowToastEvent({
            title: 'エラー',
            message: this.errorMessages,
            variant: 'error',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }

    /**
     * 機能名：画面遷移
     * 機能概要：画面遷移を行う
     */
    navigateToRecordViewPage() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                objectApiName: this.objectName,
                recordId: this.objectId,
                actionName: "view" 
            }
        });
    }
}