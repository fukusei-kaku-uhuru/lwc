import { LightningElement, api, track } from 'lwc';
import getShushiGaiyo from '@salesforce/apex/C_LWC_ShushiGinkobetsuTorihikiGaiyo_CTRL.getShushiGaiyo';
import getGinkobetsuTorihikiGaiyo from '@salesforce/apex/C_LWC_ShushiGinkobetsuTorihikiGaiyo_CTRL.getGinkobetsuTorihikiGaiyo';

export default class C_LWC_ShushiGinkobetsuTorihikiGaiyo extends LightningElement {

    @api recordId;
    @track shushiGaiyo1;
    @track shushiGaiyo2;
    @track shushiGaiyo3;
    @track ginkobetsuGaiyo1;
    @track ginkobetsuGaiyo2;
    @track ginkobetsuGaiyo3;
    @track ginkomei1;
    @track ginkomei2;

    // 画面初期表示時イベント
    connectedCallback() {

        // 取引先レコードに紐づく直近3期分の収支概要を取得する
        getShushiGaiyo({ recordId: this.recordId })
        .then(result => {
            if (result.length > 0) {
                // 降順で取得したものを昇順に変換
                let reversed = result.reverse();
                this.shushiGaiyo1 = reversed[0];
                this.shushiGaiyo1.C_KessanNengetsu__c = this.shushiGaiyo1.C_KessanNengetsu__c.substring(0, 4) + '/'
                                                        + this.shushiGaiyo1.C_KessanNengetsu__c.substring(4, 6);
                if (result.length > 1) {
                    this.shushiGaiyo2 = reversed[1];
                    this.shushiGaiyo2.C_KessanNengetsu__c = this.shushiGaiyo2.C_KessanNengetsu__c.substring(0, 4) + '/'
                                                        + this.shushiGaiyo2.C_KessanNengetsu__c.substring(4, 6);
                }
                if (result.length > 2) {
                    this.shushiGaiyo3 = reversed[2];
                    this.shushiGaiyo3.C_KessanNengetsu__c = this.shushiGaiyo3.C_KessanNengetsu__c.substring(0, 4) + '/'
                                                        + this.shushiGaiyo3.C_KessanNengetsu__c.substring(4, 6);
                }
            }
        }).catch(error => {
            console.error(error);
        });

        // 取引先レコードに紐づく直近3期分の銀行別取引概要を取得する
        getGinkobetsuTorihikiGaiyo({ recordId: this.recordId })
        .then(result => {
            if (result.length > 0) {
                // 最新期の「上位行1銀行名」「上位行2銀行名」を取得
                this.ginkomei1 = result[0].C_Joiko1Ginkomei__c;
                this.ginkomei2 = result[0].C_Joiko2Ginkomei__c;

                // 降順で取得したものを昇順に変換
                let reversed = result.reverse();
                this.ginkobetsuGaiyo1 = reversed[0];
                this.ginkobetsuGaiyo1.C_KessanNengetsu__c = this.ginkobetsuGaiyo1.C_KessanNengetsu__c.substring(0, 4) + '/'
                                                        + this.ginkobetsuGaiyo1.C_KessanNengetsu__c.substring(4, 6);
                if (result.length > 1) {
                    this.ginkobetsuGaiyo2 = reversed[1];
                    this.ginkobetsuGaiyo2.C_KessanNengetsu__c = this.ginkobetsuGaiyo2.C_KessanNengetsu__c.substring(0, 4) + '/'
                                                        + this.ginkobetsuGaiyo2.C_KessanNengetsu__c.substring(4, 6);
                }
                if (result.length > 2) {
                    this.ginkobetsuGaiyo3 = reversed[2];
                    this.ginkobetsuGaiyo3.C_KessanNengetsu__c = this.ginkobetsuGaiyo3.C_KessanNengetsu__c.substring(0, 4) + '/'
                                                        + this.ginkobetsuGaiyo3.C_KessanNengetsu__c.substring(4, 6);
                }
            }
        }).catch(error => {
            console.error(error);
        });
    }

}