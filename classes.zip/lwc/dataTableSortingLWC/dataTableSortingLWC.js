import { LightningElement, api } from 'lwc';
import getOpportunityWithOffSet from '@salesforce/apex/LWCDataTableSortingExample.getOpportunityWithOffSet';

const COLUMNS = [
    { label: '商談名', fieldName: 'Name', type: 'text'},
];

export default class OpportunityTableWithScroll extends LightningElement {
    @api recordId;
    columns = COLUMNS;
    opportunities = []
    limitRow = 20;
    rowOffSet = 0;
    status;
    limitSize = 209;
    targetDataTable;
    isFinish = false;

    connectedCallback() {
        this.loadData();
    }

    loadData() {
        getOpportunityWithOffSet({limitSize: this.limitRow, offSet: this.rowOffSet})
        .then(result => {
            let tempRecordList = [];
            for(let i = 0; i < result.length; i++) {
                let tempRecord = Object.assign({}, result[i]);
                tempRecordList.push(tempRecord);
            }
            // 取得したレコードを既存レコードリストに追加
            let currentShowRecords = [...this.opportunities, ...tempRecordList];
            this.opportunities = currentShowRecords;
            this.status = '';
            // これ以上取得するレコードがない場合はスクロール出来ないようにする

            console.log('this.opportunities.length >>' + this.opportunities.length);
            console.log('this.limitSize >>' + this.limitSize);
            console.log('tempRecordList.length >>' + tempRecordList.length);
            if(this.opportunities.length >= this.limitSize || tempRecordList.length === 0) {
                this.targetDataTable.enableInfiniteLoading = false;
                this.status = 'これ以上データはありません。';
                this.isFinish = true;
            }
            if(this.targetDataTable) {
                this.targetDataTable.isLoading = false;
            }
        }).catch(error => {
        })
    }

    /**
     * スクロール時の処理
     */
    loadNextData(event) {
        event.preventDefault();
        if(!this.isFinish) {
            event.target.isLoading = true;
            this.targetDataTable = event.target;
            this.status = 'ローディング中';
    
            this.rowOffSet += this.limitRow;
            console.log(this.rowOffSet);
            this.loadData();
        }
        
    }
}