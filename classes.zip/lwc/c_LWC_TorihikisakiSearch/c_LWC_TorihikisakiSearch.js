/*
 * 機能名：取引先検索のコンポーネント
 * 作成日：2023-09-23	
 * 作成者：HITACHI　カク
 * 更新日：2023-10-14
 * 更新者：HITACHI　カク
*/
import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { loadStyle } from "lightning/platformResourceLoader";
import WrappedHeaderTable from "@salesforce/resourceUrl/WrappedHeaderTable";

// APEX　初期化処理メソッド
import viewInit from '@salesforce/apex/C_LWC_TorihikisakiSearch_CTRL.viewInit';
// APEX　検索処理メソッド  
import searchResult from '@salesforce/apex/C_LWC_TorihikisakiSearch_CTRL.searchResult';

// 処理状態
const RESULT_STATUS_OK = 'OK';

const columns = [ { label: '取引先名', fieldName: 'torihikisakiMeiLink', sortable: "true", type: 'customLink',wrapText:true,
                    typeAttributes: { label: { fieldName: 'torihikisakiMei' }, tooltip: { fieldName: 'torihikisakiMei' }, 
                                      target: '_self',linkName:{ fieldName: 'torihikisakiMei' },link:{ fieldName: 'torihikisakiMeiLink' },
                                      objectName: 'Account', objectId: { fieldName: 'torihikisakiId' } },
                    cellAttributes: { class: { fieldName: 'linkClass' } } },
                    { label: '店番号', fieldName: 'miseBango', sortable: "true",initialWidth: 30, wrapText:true,
                    cellAttributes: { class: "slds-border_left slds-border_right" }},
                    { label: '店名', fieldName: 'tenMei', sortable: "true",initialWidth: 30, wrapText:true,
                    cellAttributes: { class: "slds-border_left slds-border_right" }},
                    { label: '取引先番号', fieldName: 'torihikisakibango', sortable: "true",initialWidth: 105,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '支援系ID', fieldName: 'shienkeiId', sortable: "true",wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '企業番号（帝国DB）', fieldName: 'kigyoBangoLink', sortable: "true",  type: 'customLink',initialWidth: 113,wrapText:true,
                    typeAttributes: { label: { fieldName: 'kigyoBango' }, tooltip: { fieldName: 'kigyoBango' },
                                      target: '_self',linkName:{ fieldName: 'kigyoBango'},link:{ fieldName: 'kigyoBangoLink' }, 
                                      objectName: 'C_T_TeikokuJoho__c', objectId: { fieldName: 'teikokuJohoId' } } ,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '所在地', fieldName: 'jyusyo', sortable: "true",initialWidth: 120,wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '業種中分類', fieldName: 'gyoshuChuBunruiShu', sortable: "true",initialWidth: 110,wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '狙い先', fieldName: 'neraisaki', sortable: "true",wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '担当者', fieldName: 'ownerName', sortable: "true",wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '謝絶記録有無', fieldName: 'shazetsukirokuUmu', initialWidth: 40,sortable: "true",wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '外部信用情報有無', fieldName: 'gaibuShinyoJoho', initialWidth: 40,sortable: "true",wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '直近接触日', fieldName: 'chokkinSesshokuBi', sortable: "true",initialWidth: 110,wrapText:true,
                    cellAttributes: { class: "slds-border_right" }},
                    { label: '評点', fieldName: 'teikokuHyoten1Hyoten', sortable: "true",wrapText:true}
                ];

export default class C_LWC_TorihikisakiSearch extends NavigationMixin(LightningElement) {

    // エラーメッセージ表示フラグ
    @track showErrorMessages = false;
    // 検索対象
    @track searchTargetValue;
    // 検索結果表示のデータ
    @track data;
    // 検索結果項目
    @track columns = columns;
    // ソート項目
    @track sortBy;
    // ソート順
    @track sortDirection;
    // すべてのデータ
    @track allData;   
    // 検索結果の初期表示件数
    lastRowNum = 200; 
    // 現在表示最後の行番号
    rowOffSet = 0;
    // 1回スクロールで表示する行数
    limitRow = 200;
    // 残データ件数
    lastDateSize;
    // テーブルコンポーネント
    targetDataTable;
    // 検索結果全件数（画面表示用）
    allDataSize = 0;
    // status;
    isLastData = true;

    // ロードフラグ
    showSpinner;
    // 店名選択値
    tenMeiSelectValue;
    // 店名オプション
    tenMeiOptions;
    // 都道府県選択値
    jyusyoValue;
    // 都道府県オプション
    stateOptions;
    // 業種中分類（帝国DB）選択値
    gyoshuChuBunruiShuValue;
    // 業種中分類（帝国DB）オプション
    gyoshuChuBunruiShuOptions;
    // 担当者
    ownerName;
    // 店番号
    tenBango;
    res;
    // エラーメッセージ
    @track errorMessage = '';

    DATA_NAME_MISEBANGO = '[data-name="miseBango"]';
    DATA_NAME_TENMEI = '[data-name="tenMei"]';
    DATA_NAME_ACCOUNTNUMBER = '[data-name="accountNumber"]';
    DATA_NAME_TOROHIKISAKIMEI = '[data-name="torihikisakiMei"]';
    DATA_NAME_TOROHIKISAKIMEIKANA = '[data-name="torihikisakiMeiKana"]';
    DATA_NAME_STATE = '[data-name="jyusyo"]';
    DATA_NAME_GYOSHUCHUBUNRUISHU = '[data-name="gyoshuChuBunruiShu"]';
    DATA_NAME_OWNERNAME = '[data-name="ownerName"]';
    DATA_NAME_SHIENKEIID = '[data-name="shienkeiId"]';
    DATA_NAME_KIGYOBANGO = '[data-name="kigyoBango"]';

    MISEBANGO_FIELD = 'miseBango';
    TENMEI_FIELD = 'tenMei';
    ACCOUNTNUMBER_FIELD = 'accountNumber';
    TOROHIKISAKIMEI_FIELD = 'torihikisakiMei';
    TOROHIKISAKIMEIKANA_FIELD = 'torihikisakiMeiKana';
    STATE_FIELD = 'jyusyo';
    GYOSHUCHUBUNRUISHU_FIELD = 'gyoshuChuBunruiShu';
    OWNERNAME_FIELD = 'ownerName';
    SHIENKEIID_FIELD = 'shienkeiId';
    KIGYOBANGO_FIELD = 'kigyoBango';
    SEARCH_TARGET_FIELD = 'searchTarget';

    /**
     * 機能名：初期処理
     * 機能概要：初期処理を行う
     */
    connectedCallback() {
        this.showSpinner = true;
        this.tenMeiSelectValue = '';
        this.jyusyoValue = '';
        this.gyoshuChuBunruiShuValue = '';
        this.searchTargetValue = '1';

        if (!this.stylesLoaded) {
            Promise.all([loadStyle(this, WrappedHeaderTable)])
                .then(() => {
                    console.log("カスタムスタイルのロードしました");
                    this.stylesLoaded = true;
                })
                .catch((error) => {
                    console.error("カスタムスタイルのロードに失敗しました。");
                });
        }

        viewInit()
            .then(result => {
                if(result.status == RESULT_STATUS_OK) {
                    this.res = result;
                    // リスト初期値を取得する
                    // 店名リスト
                    this.tenMeiOptions = this.generatePickListtenMeiOptions(result.bushoMasterList);
                    
                    // 都道府県都道府県
                    this.stateOptions = this.generatePickListStateOptions();

                    // 業種中分類（帝国DB）
                    this.gyoshuChuBunruiShuOptions = this.generatePickListGyoshuChuBunruiOptions();

                    // 店番号と担当者名を設定する
                    this.ownerName = result.ownerName;
                    this.tenBango = result.tenBango;

                    // フォーカスを店番号に設定する
                    this.template.querySelector(this.DATA_NAME_MISEBANGO).focus();
                    this.showSpinner = false;
                }
            })
            .catch(error => {
                console.log('error => ' + JSON.stringify(error));
                this.showSpinner = false;
            })
            .finally(() => {
                this.showSpinner = false;
            });
    }

    /**
     * 機能名：検索処理
     * 機能概要：検索ボタン押下時の処理
     */
    handleSearchClick() {
        const fields = {};
        
        // 入力値を取得する
        fields[this.MISEBANGO_FIELD] = this.template.querySelector(this.DATA_NAME_MISEBANGO).value;
        fields[this.TENMEI_FIELD] = this.template.querySelector(this.DATA_NAME_TENMEI).value;
        fields[this.ACCOUNTNUMBER_FIELD] = this.template.querySelector(this.DATA_NAME_ACCOUNTNUMBER).value;
        fields[this.TOROHIKISAKIMEI_FIELD] = this.template.querySelector(this.DATA_NAME_TOROHIKISAKIMEI).value;
        fields[this.TOROHIKISAKIMEIKANA_FIELD] = this.template.querySelector(this.DATA_NAME_TOROHIKISAKIMEIKANA).value;
        fields[this.STATE_FIELD] = this.template.querySelector(this.DATA_NAME_STATE).value;
        fields[this.GYOSHUCHUBUNRUISHU_FIELD] = this.template.querySelector(this.DATA_NAME_GYOSHUCHUBUNRUISHU).value;
        fields[this.OWNERNAME_FIELD] = this.template.querySelector(this.DATA_NAME_OWNERNAME).value;
        fields[this.SHIENKEIID_FIELD] = this.template.querySelector(this.DATA_NAME_SHIENKEIID).value;
        fields[this.KIGYOBANGO_FIELD] = this.template.querySelector(this.DATA_NAME_KIGYOBANGO).value;
        fields[this.SEARCH_TARGET_FIELD] = this.searchTargetValue;

        this.showErrorMessages = false;   
        // 画面にspinner（ローディング）を表示する 
        this.showSpinner = true;

        // 前回検索の変数を初期化する
        this.data;
        this.allData;
        this.lastRowNum = 200;
        this.lastDateSize = 0;
        this.rowOffSet = 0;
        this.limitRow = 200;
        this.targetDataTable='';
        this.status='';
        this.isLastData = false;
        this.errorMessage = '';
        this.sortBy = '';
        this.sortDirection = '';

        searchResult({paramsJSON : JSON.stringify(fields)})
        .then(result => {
            // チェックエラーがない場合、検索結果結果を一覧で表示する
            if(result.status == RESULT_STATUS_OK) {
                this.allData = result.resultList;
                for(let i = 0; i < this.allData.length; i++) {
                    // 取引先リンクが空の場合、リンクを表示しない
                    if(this.allData[i].torihikisakiMeiLink == null || this.allData[i].torihikisakiMeiLink == '') {
                        this.allData[i].torihikisakiMeiLink = this.allData[i].torihikisakiMei;
                        this.allData[i].linkClass = 'hideLink';
                    } 
                }
                this.allDataSize = this.allData.length;
                this.data = this.allData.slice(this.rowOffSet, this.lastRowNum);
                this.rowOffSet = this.limitRow;
                this.lastDateSize = this.allData.length - this.lastRowNum;

                if(this.allData.length > this.rowOffSet) {
                    this.isLastData = false;    
                } else {
                    this.isLastData = true;
                }
            } else {
                // チェックエラーがある場合、エラーメッセージを表示し、画面にspinner（ローディング）を非表示にして処理終了
                console.log('result Ng=> ' + JSON.stringify(result));
                this.data = null;
                this.allData = null;
                this.showSpinner = false;
                this.errorMessage = result.message;
                this.showErrorMessages = true;
            }
        })
        .catch(error => {
            console.log('error => ' + JSON.stringify(error));
            this.showSpinner = false;
            this.errorMessage = error;
            this.showErrorMessages = true;    
        })
        .finally(() => {
            this.showSpinner = false;
        });
    }

    /**
     * 機能名：店名の選択肢取得
     * 機能概要：画面初期化時、店名の選択肢を生成する
     * @param {List} result　部室店リスト
     */
    generatePickListtenMeiOptions(result) {
        const optList = [
            {label : '', value: ''},
            ...result.map(rec => {
                return {label : rec.Name, value: rec.Name};
            })
        ];
        return optList;
    }

    /**
     * 機能名：都道府県の選択肢取得
     * 機能概要：画面初期化時、都道府県の選択肢を生成する
     */
    generatePickListStateOptions(){
        const optList = [
            {label : '', value: ''},
            {label : '北海道', value: '北海道'},
            {label : '青森県', value: '青森県'},
            {label : '岩手県', value: '岩手県'},
            {label : '宮城県', value: '宮城県'},
            {label : '秋田県', value: '秋田県'},
            {label : '山形県', value: '山形県'},
            {label : '福島県', value: '福島県'},
            {label : '茨城県', value: '茨城県'},
            {label : '栃木県', value: '栃木県'},
            {label : '群馬県', value: '群馬県'},
            {label : '埼玉県', value: '埼玉県'},
            {label : '千葉県', value: '千葉県'},
            {label : '東京都', value: '東京都'},
            {label : '神奈川県', value: '神奈川県'},
            {label : '新潟県', value: '新潟県'},
            {label : '富山県', value: '富山県'},
            {label : '石川県', value: '石川県'},
            {label : '福井県', value: '福井県'},
            {label : '山梨県', value: '山梨県'},
            {label : '長野県', value: '長野県'},
            {label : '岐阜県', value: '岐阜県'},
            {label : '静岡県', value: '静岡県'},
            {label : '愛知県', value: '愛知県'},
            {label : '三重県', value: '三重県'},
            {label : '滋賀県', value: '滋賀県'},
            {label : '京都府', value: '京都府'},
            {label : '大阪府', value: '大阪府'},
            {label : '兵庫県', value: '兵庫県'},
            {label : '奈良県', value: '奈良県'},
            {label : '和歌山県', value: '和歌山県'},
            {label : '鳥取県', value: '鳥取県'},
            {label : '島根県', value: '島根県'},
            {label : '岡山県', value: '岡山県'},
            {label : '広島県', value: '広島県'},
            {label : '山口県', value: '山口県'},
            {label : '徳島県', value: '徳島県'},
            {label : '香川県', value: '香川県'},
            {label : '愛媛県', value: '愛媛県'},
            {label : '高知県', value: '高知県'},
            {label : '福岡県', value: '福岡県'},
            {label : '佐賀県', value: '佐賀県'},
            {label : '長崎県', value: '長崎県'},
            {label : '熊本県', value: '熊本県'},
            {label : '大分県', value: '大分県'},
            {label : '宮崎県', value: '宮崎県'},
            {label : '鹿児島県', value: '鹿児島県'},
            {label : '沖縄県', value: '沖縄県'},
        ];
        return optList;
    }

    /**
     * 機能名：業種中分類（帝国DB）の選択肢取得
     * 機能概要：画面初期化時、業種中分類（帝国DB）の選択肢を生成する
     */
    generatePickListGyoshuChuBunruiOptions(){
        const optList = [
            {label : '', value: ''},
            {label : '農業（農業サービス業を除く）', value: '農業（農業サービス業を除く）'},
            {label : '農業サービス業', value: '農業サービス業'},
            {label : '林業', value: '林業'},
            {label : '狩猟業', value: '狩猟業'},
            {label : '漁業', value: '漁業'},
            {label : '水産養殖業', value: '水産養殖業'},
            {label : '金属鉱業', value: '金属鉱業'},
            {label : '石炭・亜炭鉱業', value: '石炭・亜炭鉱業'},
            {label : '原油・天然ガス鉱業', value: '原油・天然ガス鉱業'},
            {label : '非金属鉱業', value: '非金属鉱業'},
            {label : '職別工事業', value: '職別工事業'},
            {label : '総合工事業', value: '総合工事業'},
            {label : '設備工事業', value: '設備工事業'},
            {label : '武器製造業', value: '武器製造業'},
            {label : '食料品・飼料・飲料製造業', value: '食料品・飼料・飲料製造業'},
            {label : 'たばこ製造業', value: 'たばこ製造業'},
            {label : '繊維工業（衣服，その他の繊維製品を除く）', value: '繊維工業（衣服，その他の繊維製品を除く）'},
            {label : '衣服・その他の繊維製品製造業', value: '衣服・その他の繊維製品製造業'},
            {label : '木材・木製品製造業（家具を除く）', value: '木材・木製品製造業（家具を除く）'},
            {label : '家具・装備品製造業', value: '家具・装備品製造業'},
            {label : 'パルプ・紙・紙加工品製造業', value: 'パルプ・紙・紙加工品製造業'},
            {label : '出版・印刷・同関連産業', value: '出版・印刷・同関連産業'},
            {label : '化学工業', value: '化学工業'},
            {label : '石油製品・石炭製品製造業', value: '石油製品・石炭製品製造業'},
            {label : 'ゴム製品製造業', value: 'ゴム製品製造業'},
            {label : '皮革・同製品・毛皮製造業', value: '皮革・同製品・毛皮製造業'},
            {label : '窯業・土石製品製造業', value: '窯業・土石製品製造業'},
            {label : '鉄鋼業，非鉄金属製造業', value: '鉄鋼業，非鉄金属製造業'},
            {label : '金属製品製造業', value: '金属製品製造業'},
            {label : '一般機械器具製造業', value: '一般機械器具製造業'},
            {label : '電気機械器具製造業', value: '電気機械器具製造業'},
            {label : '輸送用機械器具製造業', value: '輸送用機械器具製造業'},
            {label : '精密機械・医療機械器具製造業', value: '精密機械・医療機械器具製造業'},
            {label : 'その他の製造業', value: 'その他の製造業'},
            {label : '卸売業（１）', value: '卸売業（１）'},
            {label : '卸売業（２）', value: '卸売業（２）'},
            {label : '代理商，仲立業', value: '代理商，仲立業'},
            {label : '各種商品小売業', value: '各種商品小売業'},
            {label : '織物・衣服・身の回り品小売業', value: '織物・衣服・身の回り品小売業'},
            {label : '飲食料品小売業', value: '飲食料品小売業'},
            {label : '飲食店', value: '飲食店'},
            {label : '自動車・自転車小売業', value: '自動車・自転車小売業'},
            {label : '家具・じゅう器・家庭用機械器具小売業', value: '家具・じゅう器・家庭用機械器具小売業'},
            {label : 'その他の小売業', value: 'その他の小売業'},
            {label : '銀行・信託業', value: '銀行・信託業'},
            {label : '農林水産金融業', value: '農林水産金融業'},
            {label : '中小商工・庶民・住宅等金融業', value: '中小商工・庶民・住宅等金融業'},
            {label : '補助的金融業，金融付帯業', value: '補助的金融業，金融付帯業'},
            {label : '証券業，商品先物取引業', value: '証券業，商品先物取引業'},
            {label : '保険業', value: '保険業'},
            {label : '保険媒介代理業，保険サービス業', value: '保険媒介代理業，保険サービス業'},
            {label : '投資業', value: '投資業'},
            {label : '不動産業', value: '不動産業'},
            {label : '鉄道業', value: '鉄道業'},
            {label : '道路旅客運送業', value: '道路旅客運送業'},
            {label : '道路貨物運送業', value: '道路貨物運送業'},
            {label : '水運業', value: '水運業'},
            {label : '航空運輸業', value: '航空運輸業'},
            {label : '倉庫業', value: '倉庫業'},
            {label : '運輸に付帯するサービス業', value: '運輸に付帯するサービス業'},
            {label : '郵便業，電気通信業', value: '郵便業，電気通信業'},
            {label : '電気業', value: '電気業'},
            {label : 'ガス業', value: 'ガス業'},
            {label : '水道業', value: '水道業'},
            {label : '熱供給業', value: '熱供給業'},
            {label : '物品賃貸業', value: '物品賃貸業'},
            {label : '旅館，その他の宿泊所', value: '旅館，その他の宿泊所'},
            {label : '家事サービス業', value: '家事サービス業'},
            {label : '洗濯・理容・浴場業', value: '洗濯・理容・浴場業'},
            {label : 'その他の個人サービス業', value: 'その他の個人サービス業'},
            {label : '映画・ビデオ制作業', value: '映画・ビデオ制作業'},
            {label : '娯楽業', value: '娯楽業'},
            {label : '放送業', value: '放送業'},
            {label : '自動車整備業，駐車場業', value: '自動車整備業，駐車場業'},
            {label : 'その他の修理業', value: 'その他の修理業'},
            {label : '協同組合（他に分類されないもの）', value: '協同組合（他に分類されないもの）'},
            {label : '広告・調査・情報サービス業', value: '広告・調査・情報サービス業'},
            {label : 'その他の事業サービス業', value: 'その他の事業サービス業'},
            {label : '専門サービス業（他に分類されないもの）', value: '専門サービス業（他に分類されないもの）'},
            {label : '医療業', value: '医療業'},
            {label : '保健衛生，廃棄物処理業', value: '保健衛生，廃棄物処理業'},
            {label : '宗教', value: '宗教'},
            {label : '教育', value: '教育'},
            {label : '社会保険，社会福祉', value: '社会保険，社会福祉'},
            {label : '学術研究機関', value: '学術研究機関'},
            {label : '政治・経済・文化団体', value: '政治・経済・文化団体'},
            {label : 'その他のサービス業', value: 'その他のサービス業'},
            {label : '外国公務', value: '外国公務'},
            {label : '国家公務', value: '国家公務'},
            {label : '地方公務', value: '地方公務'},
            {label : '分類不能の産業', value: '分類不能の産業'}
        ];
        return optList;
    }

    /**
     * 機能名：テーブルのソート処理
     * 機能概要：検索結果一覧のヘッダーをクリックすると、指定した列をソートする
     * @param {Object} event イベント
     */
    doSorting(event) {
        this.sortBy = event.detail.fieldName;
        this.sortDirection = event.detail.sortDirection;
        this.sortData(this.sortBy, this.sortDirection);
    }

    /**
     * 機能名：データをソートする
     * 機能概要：検索結果一覧のヘッダーをクリックすると、指定した列をソートする、
     *　　　　　 初回クリック時、クリック列の昇順にソートする。再度クリックして、降順にソートする、
     *　　　　　 同列を複数回クリックした場合、繰り返し昇順降順を切替可能
     * @param {String} fieldname フィールド名
     * @param {String} direction ソート方向 ('asc' または 'desc')
     */
    sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.data));
        let keyValue = (a) => {
            return a[fieldname];
        };
        let isReverse = direction === 'asc' ? 1: -1;
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : '';
            y = keyValue(y) ? keyValue(y) : '';
            if (x === y) {
                return 0;
            }
            if (x === '') {
                // 空のデータを後ろに並べ
                return 1 * isReverse; 
            }
            if (y === '') {
                // 空のデータを後ろに並べ
                return -1 * isReverse; 
            }
            return (x > y ? 1 : -1) * isReverse;
        });
        this.data = parseData;
    }   

    /**
     * 機能名：検索区分ラジオボタンの変更処理
     * 機能概要：検索区分ラジオボタンを変更すると、他の二つラジオボタンのチェック状態をクリアする
     * @param {Object} event イベント
     */
    handleSearchTargetChange(event) {
        this.searchTargetValue = event.target.value;

        if(this.searchTargetValue == '1') {
            // 他の二つラジオボタンのチェック状態をクリアする
            this.template.querySelector('[data-name="searchTarget2"]').checked = false;
            this.template.querySelector('[data-name="searchTarget3"]').checked = false;
        } else if(this.searchTargetValue == '2') {
            // 他の二つラジオボタンのチェック状態をクリアする
            this.template.querySelector('[data-name="searchTarget1"]').checked = false;
            this.template.querySelector('[data-name="searchTarget3"]').checked = false;
        } else if(this.searchTargetValue == '3') {
            // 他の二つラジオボタンのチェック状態をクリアする
            this.template.querySelector('[data-name="searchTarget1"]').checked = false;
            this.template.querySelector('[data-name="searchTarget2"]').checked = false;
        }
    }

    /**
     * 機能名：データをロード処理
     * 機能概要：検索結果のスクロールでデータをロードする
     * @param {Object} event イベント 
     */
    loadMoreData(event) {
        event.preventDefault();
        if(!this.isLastData) {
            event.target.isLoading = true;
            this.targetDataTable = event.target;
            this.lastRowNum += this.limitRow;
            // 残データ件数を取得する
            let tempRecordList = this.allData.slice(this.rowOffSet, this.lastRowNum);
            // 取得したレコードを既存レコードリストに追加する
            let currentShowRecords = [...this.data, ...tempRecordList];
            this.data = currentShowRecords;
            this.rowOffSet += this.limitRow;
            
            // 残データ件数を取得する
            this.lastDateSize = this.allData.length - this.lastRowNum;
            this.targetDataTable.isLoading = false;
            if(this.lastDateSize <= 0) {
                this.isLastData = true;
            }
        }
    }
}