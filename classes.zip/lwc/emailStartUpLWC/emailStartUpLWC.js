import { LightningElement } from 'lwc';
import { CloseActionScreenEvent } from 'lightning/actions';

export default class EmailStartUp extends LightningElement {

 
    SaveEvent(){
    }


    connectedCallback() {
        location.href='mailto:aaaaa@hitachi.com; aaaaa@itg.hitachi.co.jp?subject=【ソリューションマッチング】メーラー起動・送信確認&amp;cc=aaaaa@hitachi.com; aaaaa@hitachi.com; aaaaa@hitachi.com; aaaaa@hitachi.com;body=To：日立平井%0D%0A%0D%0Aメーラー起動・送信HTMLの確認です。%0D%0AみずほBKのPCからメーラーを起動して送信しています。%0D%0A%0D%0Aメールが届いたら返信をお願いします。%0D%0A%0D%0Aよろしくお願いします。';
        this.dispatchEvent(new CloseActionScreenEvent());
    }
}