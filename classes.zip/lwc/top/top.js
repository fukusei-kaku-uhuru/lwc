import { LightningElement, wire } from 'lwc';
import TRAILHEAD_LOGO from '@salesforce/resourceUrl/himawari';
import TRAILHEAD_LOGO1 from '@salesforce/resourceUrl/himawari1';
import TRAILHEAD_LOGO2 from '@salesforce/resourceUrl/himawari2';
import BUTTON_IMG from '@salesforce/resourceUrl/buttonImg';
import BUTTON_IMG1 from '@salesforce/resourceUrl/buttonImg1';
import HandleClick from '@salesforce/resourceUrl/SR_Shien';
import {CurrentPageReference} from 'lightning/navigation';

const columns = [
    { label: '掲載日', fieldName: 'fieldName1', fixedWidth: 90,type: 'text' },
    { label: 'タイトル', fieldName: 'fieldName2', type: 'text' },
];

const data = [
    {
        id: 'a',
        fieldName1: '2022/9/21',
        fieldName2: 'はじめてご利用される方へ',
    },
    {
        id: 'b',
        fieldName1: '2022/9/28',
        fieldName2: '新しいコンテンツを公開しました！',
    },
];

const columns1 = [
    { label: '掲載日', fieldName: 'fieldName1', fixedWidth: 90,type: 'text' },
    { label: 'タイトル', fieldName: 'fieldName2', type: 'text' },
];

const data1 = [
    {
        id: 'a',
        fieldName1: '2022/9/26',
        fieldName2: 'アンケートの期限がまもなくです。',
    },
    {
        id: 'b',
        fieldName1: '2022/9/27',
        fieldName2: '予約したセミナーは明日です。',
    },
];

export default class Top1 extends LightningElement {
    @wire(CurrentPageReference)
    clickedButtonLabel;
    yuusiMousikomi;
    error;

    trailheadLogoUrl = TRAILHEAD_LOGO;
    trailheadLogoUrl1 = TRAILHEAD_LOGO1;
    trailheadLogoUrl2 = TRAILHEAD_LOGO2;

    buttonImg1 = BUTTON_IMG + '/buttonImg/img1.png';
    buttonImg2 = BUTTON_IMG + '/buttonImg/img2.png';
    buttonImg3 = BUTTON_IMG + '/buttonImg/img3.png';
    buttonImg4 = BUTTON_IMG + '/buttonImg/img4.png';
    buttonImg5 = BUTTON_IMG + '/buttonImg/img5.png';
    buttonImg6_1 = BUTTON_IMG + '/buttonImg/img6-1.png';
    buttonImg6_2 = BUTTON_IMG + '/buttonImg/img6-2.png';
    buttonImg7 = BUTTON_IMG + '/buttonImg/img7.png';
    buttonImg8 = BUTTON_IMG + '/buttonImg/img8.png';
    buttonImg9 = BUTTON_IMG + '/buttonImg/img9.png';
    buttonImg10 = BUTTON_IMG + '/buttonImg/img10.png';
    buttonImg11 = BUTTON_IMG + '/buttonImg/img11.png';

    content1 = BUTTON_IMG1 + '/buttonImg1/content3.png';
    content2 = BUTTON_IMG1 + '/buttonImg1/content4.png';

    handleClick3 = HandleClick + '/TaskList.html';


    handleClick(event) {
        this.clickedButtonLabel = event.target.label;
    }

    handleLoad() {
        getYuusiMousikomiList()
            .then(result => {
                this.yuusiMousikomi = result;
            })
            .catch(error => {
                this.error = error;
            });
    }

    handleClick1(event) {
        if (event.target.name === 'button1') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick2(event) {
        if (event.target.name === 'button2') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick3(event) {
        if (event.target.name === 'button3') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
            //window.location.href=handleClick3;
        }
    }

    handleClick4(event) {
        if (event.target.name === 'button4') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/yuusiMousikomi';
        }
    }

    handleClick5(event) {
        if (event.target.name === 'button5') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick6(event) {
        if (event.target.name === 'button6') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick7(event) {
        if (event.target.name === 'button7') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick8(event) {
        if (event.target.name === 'button8') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick9(event) {
        if (event.target.name === 'button9') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick10(event) {
        if (event.target.name === 'button10') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick11(event) {
        if (event.target.name === 'button11') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    data = data;
    columns = columns;

    data1 = data1;
    columns1 = columns1;

    getSelectedName(event) {
        const selectedRows = event.detail.selectedRows;
        // Display that fieldName of the selected rows
        for (let i = 0; i < selectedRows.length; i++) {
            alert('You selected: ' + selectedRows[i].opportunityName);
        }
    }

    getSelectedName1(event) {
        const selectedRows = event.detail.selectedRows;
        // Display that fieldName of the selected rows
        for (let i = 0; i < selectedRows.length; i++) {
            alert('You selected: ' + selectedRows[i].opportunityName);
        }
    }
}