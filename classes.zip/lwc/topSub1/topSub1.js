import { LightningElement } from 'lwc';

const columns = [
    { label: '掲載日', 
        fieldName: 'fieldName1', 
        fixedWidth: 100,
        type: 'text', 
        hideDefaultActions: 'true'
    },
    { label: 'タイトル',
        fieldName: 'fieldName2',
        type: 'text',
        hideDefaultActions: 'true' 
    }
];

const data = [
    {
        id: 'a',
        fieldName1: '2022/9/28',
        fieldName2: '新しいコンテンツを公開しました！',
    },
    {
        id: 'b',
        fieldName1: '2022/9/21',
        fieldName2: 'はじめてご利用される方へ',
    },
    {
        id: 'c',
        fieldName1: '',
        fieldName2: '全て表示',
    },
];

export default class TopSub1 extends LightningElement {

    data = data;
    columns = columns;

    getSelectedName(event) {
        const selectedRows = event.detail.selectedRows;
        // Display that fieldName of the selected rows
        for (let i = 0; i < selectedRows.length; i++) {
            alert('You selected: ' + selectedRows[i].opportunityName);
        }
    }
}