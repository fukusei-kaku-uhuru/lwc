import { LightningElement } from 'lwc';
import BUTTON_IMG1 from '@salesforce/resourceUrl/buttonImg1';

export default class TopSub4 extends LightningElement {
    content1 = BUTTON_IMG1 + '/buttonImg1/content3.png';
    content2 = BUTTON_IMG1 + '/buttonImg1/content4.png';
}