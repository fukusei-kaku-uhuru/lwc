import { LightningElement } from 'lwc';

const columns1 = [
    { label: '掲載日', fieldName: 'fieldName1', fixedWidth: 90,type: 'text',hideDefaultActions: 'true' },
    { label: 'タイトル', fieldName: 'fieldName2', type: 'text',hideDefaultActions: 'true' },
];

const data1 = [
    {
        id: 'a',
        fieldName1: '2022/10/25',
        fieldName2: 'アンケートの期限がまもなくです。',
    },
    {
        id: 'b',
        fieldName1: '2022/10/21',
        fieldName2: '予約したセミナーは明日です。',
    },
];

export default class TopSub2 extends LightningElement {

    data1 = data1;
    columns1 = columns1;

    getSelectedName1(event) {
        const selectedRows = event.detail.selectedRows;
        // Display that fieldName of the selected rows
        for (let i = 0; i < selectedRows.length; i++) {
            alert('You selected: ' + selectedRows[i].opportunityName);
        }
    }
}