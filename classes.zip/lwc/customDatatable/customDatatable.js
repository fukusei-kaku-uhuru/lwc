/*
 * 機能名：（共通）カスタムDataTableのコンポーネント
 * 作成日：2023-10-14	
 * 作成者：HITACHI　カク
 * 更新日：2023-10-14
 * 更新者：HITACHI　カク
*/
import LightningDatatable from 'lightning/datatable';
import link from './customLink.html';

export default class CustomDatatable extends LightningDatatable {
   // カスタムデータタイプの定義 
   static customTypes = {
        customLink: {
            template: link,
            typeAttributes: ['linkName','objectName','objectId','link']
        },
   };

}