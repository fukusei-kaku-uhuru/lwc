import { LightningElement, wire, track} from 'lwc';
import getYuusiMousikomiList from '@salesforce/apex/yuusiMousikomiController.getYuusiMousikomiList';
import { NavigationMixin } from 'lightning/navigation';

const columns = [
    { label: '内容', fieldName: 'Naiyo__c',hideDefaultActions: 'true' },
    { label: '金額', fieldName: 'Amount__c' ,type: 'currency',hideDefaultActions: 'true'},
    { label: '期間', fieldName: 'Period__c',hideDefaultActions: 'true' },
    { label: '必要時期', fieldName: 'NecessaryPeriod__c', type: "date-local",hideDefaultActions: 'true',
        typeAttributes: {
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }},
    { label: '返済条件', fieldName: 'RepaymentTerms__c',hideDefaultActions: 'true'},
    { label: '資金使途', fieldName: 'UseFunds__c',hideDefaultActions: 'true'},
    { label: '必要事情', fieldName: 'NecessaryCIS__c',hideDefaultActions: 'true'},
];

export default class YuusiMousikomi extends NavigationMixin(LightningElement) {
    @track yuusiMousikomi = [];
    @track error;
    @track Amount;
    columns = columns;
    @wire(getYuusiMousikomiList)


    getYuusiMousikomiList( { error, data } ){
        if(data){
            this.yuusiMousikomi = data;
            //this.Amount = yuusiMousikomi.fields.Amount__c.value;
            console.log('******* : ' + this.yuusiMousikomi[0].Amount__c);
        }else if(error){
            // トーストでエラー表示
            //this.showToast( ERROR_GETCONTACTS, error.details.body.message, 'error', 'sticky');
        }
    }

    handleClick(event) {
        if (event.target.name === 'button1') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/recordlist/T_YushiMoshikomi__c/Default';
          }
    }

    navigateToFiles() {
        console.log('********* : ' + standard__namedPage);
        this[NavigationMixin.Navigate]({
          type: 'standard__namedPage',
          attributes: {
              pageName: 'filePreview'
          },
          state : {
              recordIds: '0695g000008MuFRAA0',
              selectedRecordId:'0695g000008MuFRAA0'
          }
        })
    }

    pdfDownloadLink = 'https://hitachi-solutionscom6.file.force.com/sfc/dist/version/download/?oid=00D5g00000ELTgU&ids=0685g000008RXbL&d=%2Fa%2F5g000000kIam%2Fkbs7lsm4wznfinrvnAkKbMMglhIA5RNHYgJdRcVUJ4I&asPdf=false';
}