import { LightningElement, wire } from 'lwc';
import BUTTON_IMG from '@salesforce/resourceUrl/buttonImg';
import BUTTON_Link from '@salesforce/resourceUrl/SR_DenshiKeiyaku';
import { NavigationMixin } from 'lightning/navigation';

export default class TopSub5 extends LightningElement {

    buttonImg1 = BUTTON_IMG + '/buttonImg/img1.png';
    buttonImg2 = BUTTON_IMG + '/buttonImg/img2.png';
    buttonImg3 = BUTTON_IMG + '/buttonImg/img3.png';
    buttonImg4 = BUTTON_IMG + '/buttonImg/img4.png';
    buttonImg5 = BUTTON_IMG + '/buttonImg/img5.png';
    buttonImg6_1 = BUTTON_IMG + '/buttonImg/img6-1.png';
    buttonImg6_2 = BUTTON_IMG + '/buttonImg/img6-2.png';
    buttonImg7 = BUTTON_IMG + '/buttonImg/img7.png';
    buttonImg8 = BUTTON_IMG + '/buttonImg/img8.png';
    buttonImg9 = BUTTON_IMG + '/buttonImg/img9.png';
    buttonImg10 = BUTTON_IMG + '/buttonImg/img10.png';
    buttonImg11 = BUTTON_IMG + '/buttonImg/img11.png';

    buttonlink = BUTTON_Link + '/DenshiK.html';

    handleClick1(event) {
        if (event.target.name === 'button1') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick2(event) {
        if (event.target.name === 'button2') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick3(event) {
        console.log('*****: ' + BUTTON_Link);
        if (event.target.name === 'button3') {
            window.open('/portal/resource/1664420110000/SR_DenshiKeiyaku/DenshiK.html');
        }
    }

    handleClick4(event) {
        if (event.target.name === 'button4') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/yuusiMousikomi';
        }
    }

    handleClick5(event) {
        if (event.target.name === 'button5') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick6(event) {
        if (event.target.name === 'button6') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick7(event) {
        if (event.target.name === 'button7') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick8(event) {
        if (event.target.name === 'button8') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick9(event) {
        if (event.target.name === 'button9') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }

    handleClick10(event) {
        if (event.target.name === 'button10') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/seminar/Seminar__c';
        }
    }

    handleClick11(event) {
        if (event.target.name === 'button11') {
            window.location.href='https://hitachi-solutionscom6.my.site.com/portal/s/';
        }
    }
}