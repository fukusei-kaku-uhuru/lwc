import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'

import CAM_M0037 from "@salesforce/label/c.CAM_M0037";
import CAM_M0038 from "@salesforce/label/c.CAM_M0038";

import searchKariCif from '@salesforce/apex/C_TR_TorihikisakiMaintenance_CTRL.searchKariCif';
import searchHonCif from '@salesforce/apex/C_TR_TorihikisakiMaintenance_CTRL.searchHonCif';

import checkSystemManager from '@salesforce/apex/C_TR_TorihikisakiMaintenance_CTRL.checkSystemManager';
import preExecuteDml from '@salesforce/apex/C_TR_TorihikisakiMaintenance_CTRL.preExecuteDml';
import execTorihikisakiMaintenance from '@salesforce/apex/C_TR_TorihikisakiMaintenance_CTRL.execTorihikisakiMaintenance';

import LightningConfirm from 'lightning/confirm';

export default class C_LWC_TorihikisakiMaintenance extends NavigationMixin(LightningElement) {

    showSpinner;
    kariCifId;
    honCifId;
    warnMessage = CAM_M0037;
    @track errorMessages;
    @track kariCifName;
    @track honCifName;
    @track isRecoveryMode = false;
    @track isSystemManager = false;

    connectedCallback() {
        checkSystemManager()
        .then(result => {
            this.isSystemManager = result;
        }).catch(error => {
            console.error(error);
        });
    }

    handleChangeRecoveryMode(event) {
        this.isRecoveryMode = this.template.querySelector('lightning-input[data-name="isRecoveryMode"]').checked;
        let inputMiseBango = this.template.querySelector('lightning-input[data-name="miseBango"]');
        let inputAccountNumber = this.template.querySelector('lightning-input[data-name="accountNumber"]');
        inputMiseBango.required = !this.isRecoveryMode;
        inputAccountNumber.required = !this.isRecoveryMode;
        if (this.isRecoveryMode) {
            inputMiseBango.value = "";
            inputAccountNumber.value = "";
            inputMiseBango.reportValidity();
            inputAccountNumber.reportValidity();
        }
    }
    
    handleSearchKariCifClick(event) {
        this.showSpinner = true;
        this.errorMessages = "";
        this.kariCifId = "";
        this.kariCifName = "";
        let inputShienkeiId = this.template.querySelector('lightning-input[data-name="shienkeiId"]');
        inputShienkeiId.reportValidity();
        if (inputShienkeiId.value == '') {
            this.showSpinner = false;
            return;
        }
        searchKariCif({ shienkeiId: inputShienkeiId.value })
            .then(result => {
                if (result) {
                    this.kariCifId = result.Id;
                    this.kariCifName = result.Name;
                }
            }).catch(error => {
                if (Array.isArray(error.body)) {
                    this.errorMessages = error.body.map((e) => e.message);
                } else if (error.body && typeof error.body.message === 'string') {
                    this.errorMessages = [ error.body.message ];
                }
            }).finally(() => {
                this.showSpinner = false;
            });
    }

    handleSearchHonCifClick(event) {
        this.showSpinner = true;
        this.errorMessages = "";
        this.honCifId = "";
        this.honCifName = "";
        let inputMiseBango = this.template.querySelector('lightning-input[data-name="miseBango"]');
        let inputAccountNumber = this.template.querySelector('lightning-input[data-name="accountNumber"]');
        inputMiseBango.reportValidity();
        inputAccountNumber.reportValidity();
        if (inputAccountNumber.value == '' || inputMiseBango.value == '') {
            this.showSpinner = false;
            return;
        }
        searchHonCif({ accountNumber: inputAccountNumber.value, miseBango: inputMiseBango.value })
            .then(result => {
                if (result) {
                    this.honCifId = result.Id;
                    this.honCifName = result.Name;
                }
            }).catch(error => {
                if (Array.isArray(error.body)) {
                    this.errorMessages = error.body.map((e) => e.message);
                } else if (error.body && typeof error.body.message === 'string') {
                    this.errorMessages = [ error.body.message ];
                }
            }).finally(() => {
                this.showSpinner = false;
            });
    }


    async handleExecClick(event) {

        this.showSpinner = true;
        this.errorMessages = "";
        let isValid = true;
        
        // 入力値チェックNGなら処理終了
        if (this.kariCifId  == null || this.kariCifId  == '' || this.honCifId == null || this.honCifId == '') {
            this.errorMessages = [ '入力された支援系IDでは取引先メンテナンスが実行されていないため、戻し実行はできません。' ];
            this.showSpinner = false;
            return;
        } else {
            // this.errorMessages = [ '実行処理が異常終了しました。システム管理者に確認ください。' ];
            // this.showSpinner = false;
            // return;
        }

        // 実行確認
        const result = await LightningConfirm.open({
            message: '実行します。よろしいですか？',
            //message: CAM_M0038,
            variant: 'headerless'
        });

        // キャンセル押されたら処理終了
        if (!result) {
            this.showSpinner = false;
            return;
        }
        
        // 事前DML検証
        await preExecuteDml({ kariCifId: this.kariCifId, honCifId: this.honCifId })
            .then(result => {
                if (result) {
                    this.errorMessages = result;
                    if (result.length > 0) {
                        isValid = false;
                    }
                }
            }).catch(error => {
                console.error(error);
                this.errorMessages = [ error.message ];
                isValid = false;
            });

        // 事前DML検証でエラーが発生したら処理終了
        if (!isValid) {
            this.showSpinner = false;
            return;
        }

        // メイン処理実行
        await execTorihikisakiMaintenance({ kariCifId: this.kariCifId, honCifId: this.honCifId })
            .then(result => {
                if (result) {
                    this.errorMessages = result;
                    if (result.length > 0) {
                        isValid = false;
                    }
                }
            }).catch(error => {
                console.error(error);
                this.errorMessages = [ error.message ];
                isValid = false;
            });

        // メイン処理でエラーが発生したら処理終了
        if (!isValid) {
            this.showSpinner = false;
            return;
        }

        // 最後まで行ったら画面遷移
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.honCifId,
                actionName: 'view'
            }
        });
        this.showSpinner = false;

        // トーストを表示
        const toastEvent = new ShowToastEvent({
            message: '取引先メンテナンスが完了しました。',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(toastEvent);
    }

}